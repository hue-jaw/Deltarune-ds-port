Place Undertale Yellow 'data.win' here:
/snail-pie/undertale_yellow/data.win
