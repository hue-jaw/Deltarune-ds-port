Drop data.win, game.win, or game files for deltarune_ch1 here!
Snail Pie DS will automatically scan and run this game.
