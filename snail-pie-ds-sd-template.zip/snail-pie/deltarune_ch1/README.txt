Place official Deltarune Chapter 1 'data.win' here:
/snail-pie/deltarune_ch1/data.win
