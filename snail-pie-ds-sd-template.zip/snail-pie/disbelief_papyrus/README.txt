Place Disbelief Papyrus 'data.win' here:
/snail-pie/disbelief_papyrus/data.win
