Place official Deltarune Chapter 2 'data.win' here:
/snail-pie/deltarune_ch2/data.win
