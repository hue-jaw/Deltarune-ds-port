Drop data.win, game.win, or game files for deltarune_ch2 here!
Snail Pie DS will automatically scan and run this game.
