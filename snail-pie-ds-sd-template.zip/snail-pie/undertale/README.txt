Place official Undertale 'data.win' (or 'game.win') here:
/snail-pie/undertale/data.win
