=====================================================
          🥧 SNAIL PIE DS - SD CARD DIRECTORY 🥧
=====================================================
Place this entire 'snail-pie' folder at the root of
your Nintendo DS / DSi / 3DS SD card (e.g., sd:/snail-pie/).

You can drop any Deltarune, Undertale, or Fan Game
here, and Snail Pie DS will automatically detect,
compile, and run them!

SUBFOLDERS INCLUDED:
- deltarune_ch1/       -> Deltarune Chapter 1 (data.win / game files)
- deltarune_ch2/       -> Deltarune Chapter 2 (data.win / game files)
- undertale/           -> Undertale (data.win / game files)
- undertale_yellow/    -> Undertale Yellow (Team Undertale Yellow)
- ts_underswap/        -> TS!Underswap (Team Swapped)
- disbelief_papyrus/   -> Disbelief Papyrus
- sans_fight/          -> Bad Time Simulator (Sans Fight)

CONTROLS IN SNAIL PIE DS:
[D-PAD / TOUCH]  Browse installed games
[A / TOUCH]      Launch selected game
[X]              Create default sample folders
[Y]              Rescan /snail-pie/
[SELECT]         Open Guide / Return to Launcher from any game
=====================================================
