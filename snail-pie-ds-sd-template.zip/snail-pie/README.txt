================================================================================
          SNAIL PIE DS v1.1 - GameMaker Studio NDS Runner & Translator
================================================================================

Inspired by the Butterscotch architecture, Snail Pie DS v1.1 is a direct
GameMaker Studio runtime for Nintendo DS flashcarts (R4, DSTWO, Acekard, TwilightMenu++).

It reads official PC/Console GameMaker data (`data.win` or `game.win`) directly
from your SD card, dynamically translating maps, sprites, rooms, and audio into
NDS-native hardware formats while overcoming the 4MB RAM limit via SD streaming.

--------------------------------------------------------------------------------
HOW TO PLAY OFFICIAL DELTARUNE ON NDS:
--------------------------------------------------------------------------------
1. Copy the entire 'snail-pie' folder to the ROOT of your microSD card:
      microSD:/snail-pie/

2. From your Deltarune PC installation (Steam or itch.io):
   - Locate 'data.win' (approx. 13.7 MB for Chapter 1).
   - Copy 'data.win' into:
      microSD:/snail-pie/deltarune_ch1/data.win

3. (Optional) For Chapter 2:
   - Copy Chapter 2's 'data.win' into:
      microSD:/snail-pie/deltarune_ch2/data.win

4. Put your microSD card back into your Nintendo DS flashcart and launch
   'Deltarune.nds' (or 'SnailPieDS.nds').

5. Snail Pie DS will automatically detect the game in the menu! Select it and
   press [A] PLAY to launch into the full authentic GameMaker experience with
   scrolling 2000x680 rooms, animated sprites, and streaming audio!

--------------------------------------------------------------------------------
SUPPORTED GAMES:
--------------------------------------------------------------------------------
* Deltarune Chapter 1 (/snail-pie/deltarune_ch1/data.win)
* Deltarune Chapter 2 (/snail-pie/deltarune_ch2/data.win)
* Undertale (/snail-pie/undertale/data.win)
* Undertale Yellow (/snail-pie/undertale_yellow/data.win)
* TS!Underswap (/snail-pie/ts_underswap/data.win)
* Disbelief Papyrus & Custom Fan Games

Enjoy the official Deltarune experience on your Nintendo DS!
================================================================================
