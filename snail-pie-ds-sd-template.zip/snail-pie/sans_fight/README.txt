Drop data.win, game.win, or game files for sans_fight here!
Snail Pie DS will automatically scan and run this game.
