Place Bad Time Simulator / Sans Fight 'data.win' here:
/snail-pie/sans_fight/data.win
